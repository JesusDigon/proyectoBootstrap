<html>
<head>
	<title>Subir imagen</title>
</head>
<body>
<?php
$formulario= <<<MarcaFinal
	<form action='subirImagen.php' method='POST' ENCTYPE='multipart/form-data'>
	<p>Suba su imagen:
	<input type="hidden" name="MAX_FILE_SIZE" value="300000" />
	<input type="file" name="imagen1"/>
	<input type="file" name="imagen2"/><br>
	<input type="submit" value="enviar"/>
	</form>
MarcaFinal;



if($_SERVER['REQUEST_METHOD']=='GET'){ //Si es método get muestra formulario
    echo $formulario;
    }else{//sino procesa los archivos

// se incluyen los códigos de error que produce la subida de archivos en PHPP
// Posibles errores de subida
$codigosErrorSubida= [ 
    0 => 'Subida correcta',
    1 => 'El tamaño del archivo excede el admitido por el servidor',  // directiva upload_max_filesize en php.ini
    2 => 'El tamaño del archivo excede el admitido por el cliente',  // directiva MAX_FILE_SIZE en el formulario HTML
    3 => 'El archivo no se pudo subir completamente',
    4 => 'No se seleccionó ningún archivo para ser subido',
    6 => 'No existe un directorio temporal donde subir el archivo',
    7 => 'No se pudo guardar el archivo en disco',  // permisos
    8 => 'Una extensión PHP evito la subida del archivo'  // extensión PHP
]; 
$mensaje = '';
$directorioSubida = "/home/alummo2019-20/imgusers"; // directorio donde se guardará/n las imagen/es
$nombreFichero   =   $_FILES['imagen1']['name'];
$tipoFichero     =   $_FILES['imagen1']['type'];
$tamanioFichero  =   $_FILES['imagen1']['size'];
$temporalFichero =   $_FILES['imagen1']['tmp_name'];
$errorFichero    =   $_FILES['imagen1']['error'];
//info fichero 2
$nombreFichero2   =   $_FILES['imagen2']['name'];
$tipoFichero2     =   $_FILES['imagen2']['type'];
$tamanioFichero2  =   $_FILES['imagen2']['size'];
$temporalFichero2 =   $_FILES['imagen2']['tmp_name'];
$errorFichero2    =   $_FILES['imagen2']['error'];
$mensaje .= '<br />RESULTADO<br />';

//compruebo si hay dos archivos
 
print_r($_FILES);

if((ComprobarSubida($_FILES['imagen1']['name'])) && (ComprobarSubida($_FILES['imagen2']['name']))){
    $tamañoMaximo=300*1024;
    if ($errorFichero > 0 || $errorFichero2>0) {//compruebo si hay errores
        $mensaje .= "Se a producido el error: ".$errorFichero.": ". $codigosErrorSubida[$errorFichero];
    } else { 
    if(ComprobarDirectorio($directorioSubida)){//compruebo directorio
        if(ComprobarTamaño($tamañoMaximo, $tamanioFichero+$tamanioFichero2)){//compruebo tamaño
            if (move_uploaded_file($temporalFichero,  $directorioSubida .'/'. $nombreFichero) && (move_uploaded_file($temporalFichero2,  $directorioSubida .'/'. $nombreFichero2))) {//lo muevo
                $mensaje .= 'Archivo guardado en: ' . $directorioSubida .'/'. $nombreFichero . ' <br />';
                $mensaje .= 'Archivo guardado en: ' . $directorioSubida .'/'. $nombreFichero2 . ' <br />';
            } else {
                $mensaje .= 'ERROR: Archivo no guardado correctamente <br />';
            }
        }
    }
    }
    
    //compruebo si solo se subió el archivo 1
}elseif(ComprobarSubida($_FILES['imagen1']['name'])){
    $tamañoMaximo=200*1024;
    if ($errorFichero > 0){
            $mensaje .= "Se a producido el error: ".$errorFichero.": ". $codigosErrorSubida[$errorFichero];
        } else {
            if(ComprobarDirectorio($directorioSubida)){//compruebo directorio
                if(ComprobarTamaño($tamañoMaximo, $tamanioFichero)){//compruebo tamaño
                    if (move_uploaded_file($temporalFichero,  $directorioSubida .'/'. $nombreFichero) == true) {//lo muevo
                        $mensaje .= 'Archivo guardado en: ' . $directorioSubida .'/'. $nombreFichero . ' <br />';
                    } else {
                        $mensaje .= 'ERROR: Archivo no guardado correctamente <br />';
                    }
                }
            }
        }
        
        //compruebo si solo se envio el segundo archivo
}elseif(ComprobarSubida($_FILES['imagen2']['name'])){
    $tamañoMaximo=200*1024;
    if ($errorFichero2 > 0){
        $mensaje .= "Se a producido el error: ".$errorFichero2.": ". $codigosErrorSubida[$errorFichero2];
    } else {
        if(ComprobarDirectorio($directorioSubida)){//compruebo directorio
            if(ComprobarTamaño($tamañoMaximo, $tamanioFichero2)){//compruebo tamaño
                if (move_uploaded_file($temporalFichero2,  $directorioSubida .'/'. $nombreFichero2) == true) {//lo muevo
                    $mensaje .= 'Archivo guardado en: ' . $directorioSubida .'/'. $nombreFichero2 . ' <br />';
                } else {
                    $mensaje .= 'ERROR: Archivo no guardado correctamente <br />';
                }
            }
        }
    }
}
   
        
          
        
         
       
    

    
 
echo $mensaje;
    }

function ComprobarSubida($nombre){
        if(!isset($nombre)){//comprueba si se envia algún archivo
            return false;
        }else{
            return true;
        }
        
    }
function ComprobarDirectorio($directorio){
        if ( is_dir($directorio) && is_writable ($directorio)){
            return true;
        }else{
            return false;
        }
    }
function ComprobarTamaño($tamaño, $tamanioFichero){
    if($tamaño>$tamanioFichero){
        return true;
    }else{
        return false;
    }
}
?>

</body>
</html>