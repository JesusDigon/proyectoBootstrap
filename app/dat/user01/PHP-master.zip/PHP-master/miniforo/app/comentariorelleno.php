<!DOCTYPE html>
<html>
<head>
	<title>Comentario Relleno</title>
</head>
<body>
<form action="index.php" method="POST">
<p>Tema</p>
<input type="text" name="Tema" placeholder="Introduzca un asunto" value="<?=(isset($_REQUEST['Tema']))?strip_tags($_REQUEST['Tema']):''?>"><br>
<p>Comentario: </p>
<textarea name="cajaTexto" rows="10" cols="30" ><?=(isset($_REQUEST['cajaTexto']))?strip_tags($_REQUEST['cajaTexto']):''?></textarea><br>
<input type="submit" name="orden" value="Nueva opinión">
<input type="submit" name="orden" value="Detalles">
<input type="submit" name="orden" value="Terminar">
</form>
</body>
</html>