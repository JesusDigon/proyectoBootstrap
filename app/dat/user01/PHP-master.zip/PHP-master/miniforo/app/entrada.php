<!DOCTYPE html>
<html>
<head>
	<title>Entrada</title>
	<link rel="stylesheet" type="text/css" href="../web/index.css">
</head>
<body>
<form action="index.php" method="POST">
	<p>Usuario: <input name="nombre" type="text" value="<?=(isset($_REQUEST['nombre']))?$_REQUEST['nombre']:''?>"></p>
	<p>Contraseña: <input name="contraseña" type="password" value="<?=(isset($_REQUEST['contraseña']))?$_REQUEST['contraseña']:''?>"></p>
	<input type="submit" id="boton" name="orden" value="Entrar">
</form>
</body>
</html>