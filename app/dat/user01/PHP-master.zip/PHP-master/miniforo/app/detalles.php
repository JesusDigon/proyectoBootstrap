<?php 

function EncontrarLetraMasRepetido($cadena){
    $cadena1=str_replace(" ", "", $cadena);
    $contador=count_chars($cadena1,1);
	$maximo=0;
	$cmasrep="";
	foreach($contador as $clave => $valor){
		if($valor>$maximo){
			$cmasrep=chr($clave);
			$maximo=$valor;
		}
	}
	return $cmasrep;

}
function EncontrarPalabraMasRepetida($cadena){
	$cadena1=explode(" ",$cadena);
	$masrepetido="";
	$maximo=0;
	foreach ($cadena1 as $clave => $valor) {
		if(substr_count($cadena, $valor)>$maximo){
			$masrepetido=$valor;
			$maximo=substr_count($cadena, $valor);
		}
	}
	return $masrepetido;
}
if($_REQUEST['Tema']==="" && $_REQUEST['cajaTexto']===""){
	echo "<p>Introduzca algún Tema/Comentario para poder ver los detalles.</p>";

}else{
	echo "<p>Detalles:</p>";
	echo "<p>Longitud: ".str_replace(" ", "", strlen($_REQUEST['cajaTexto']))."</p>";
	echo "<p>Número de palabras: ".str_word_count($_REQUEST['cajaTexto'])."</p>";
	echo "<p>Letra más repetida: ".EncontrarLetraMasRepetido($_REQUEST['cajaTexto'])."</p>";
	echo "<p>Palabra más repetida: ".EncontrarPalabraMasRepetida($_REQUEST['cajaTexto'])."</p>";

}

?>