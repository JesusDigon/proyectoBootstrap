<?php 
function usuarioOK($nombre, $contraseña){
	if(strlen($nombre)>=8 && strrev($nombre)===$contraseña){
		return true;
	}else{
		return false;
	}
}
?>