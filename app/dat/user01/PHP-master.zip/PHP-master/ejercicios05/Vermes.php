<?php 
if ($_SERVER['REQUEST_METHOD']=='GET'){
    
}else{
    header("location: VermesResul.php");
}
    ?>
<html>
<head>
<title>5.3</title>
<meta charset="UTF-8"/>
<style type="text/css">


</style>
</head>
<body>
<form action="VermesResul.php" method="post">
<h1>Bienvenido al generador de calendarios</h1>
Mes: <select name="Mes">
<option value="Jan">Enero</option>
<option value="Feb">Feberero</option>
<option value="Mar">Marzo</option>
<option value="Apr">Abril</option>
<option value="May">Mayo</option>
<option value="Jun">Junio</option>
<option value="Jul">Julio</option>
<option value="Aug">Agosto</option>
<option value="Sep">Septiembre</option>
<option value="Oct">Octubre</option>
<option value="Nov">Noviembre</option>
<option value="Dec">Diciembre</option>
</select>
Año: <select name="Año">

<?php CrearSelectAño(); ?>
</select>
<input type="submit" value="Enviar">
</form>
<?php 
function CrearSelectAño(){
    for ($i=1980;$i<=date('Y');$i++){
        echo "<option value='".$i."'>$i</option>";
    }
}
?>

</body>
</html>