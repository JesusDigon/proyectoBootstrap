<html>
<head>
<meta charset="UTF-8"/>
<title>5.1</title>
</head>
<body>
<h1>Cálculo de letra DNI: </h1>
<form action="nif.php" method="POST">
<?php

$tabla=["T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"];

if ($_SERVER['REQUEST_METHOD']=="GET"){
     $letra="";
}else{
   $dni=$_POST['dni']; 
   while(TRUE){
       $dni+=0;
       is_numeric($dni);
       strlen($dni)==8;
      
       $letra=$tabla[$dni%23];
       break;
   }
}
?>
<p>Dni: <input type="text" name="dni" size="8" maxlength="8" minlength="8" /> Letra: <?php echo $letra;?></p>
<input type="submit" value="enviar"/>
</form>
</body>
</html>