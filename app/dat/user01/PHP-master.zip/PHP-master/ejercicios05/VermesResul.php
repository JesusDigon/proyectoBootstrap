
<html>
<head>
<title>5.3</title>
<meta charset="UTF-8"/>
<style type="text/css">
*{
margin:0;
padding:0;
}

table{
    width:49%;
    height:auto;
    display:inline-block;
    text:align-center;
 }
 form{
    width:49%;
    height:auto;
    display:inline-block;
    text-align:center;
 }
 h1{
 padding:20px;
 }
 select{
 padding: 5px;
 }
</style>
</head>
<body>
<form action="VermesResul.php" method="post">
<h1>Bienvenido al generador de calendarios</h1>
Mes: <select name="Mes">
<option value="Jan">Enero</option>
<option value="Feb">Feberero</option>
<option value="Mar">Marzo</option>
<option value="Apr">Abril</option>
<option value="May">Mayo</option>
<option value="Jun">Junio</option>
<option value="Jul">Julio</option>
<option value="Aug">Agosto</option>
<option value="Sep">Septiembre</option>
<option value="Oct">Octubre</option>
<option value="Nov">Noviembre</option>
<option value="Dec">Diciembre</option>
</select><br>
Año: <select name="Año">

<?php CrearSelectAño(); ?>
</select><br>
<input type="submit" value="Enviar">
</form>
<?php
$arrayMes= ["Jan"=>"Enero",
"Feb"=>"Feberero",
"Mar"=>"Marzo",
"Apr"=>"Abril",
"May"=>"Mayo",
"Jun"=>"Junio",
"Jul"=>"Julio",
"Aug"=>"Agosto",
"Sep"=>"Septiembre",
"Oct"=>"Octubre",
"Nov"=>"Noviembre",
"Dec"=>"Diciembre"];
$diaSemana=date("w", strtotime("1 ".$_POST['Mes']." ".$_POST['Año']));
$numeroDiasMes=date("t",  strtotime("1 ".$_POST['Mes']." ".$_POST['Año']));
$Mes=$arrayMes[$_POST['Mes']];
?>

<table>
<tr>
	<td colspan="7">Mes: <?php echo $Mes."     ".$_POST['Año'];?></td>
	</tr><tr>
	<td>L</td>
	<td>M</td>
	<td>X</td>
	<td>J</td>
	<td>V</td>
	<td>S</td>
	<td>D</td>
	</tr>
	<?php Calendario($numeroDiasMes,$diaSemana); ?>
<tr><td colspan="7"><form action="Vermes.php">
<input type="submit" value="Recargar">
</form></td></tr>	
</table>


<?php
setlocale(LC_ALL, 'es_ES');
function CrearSelectAño(){
    for ($i=1980;$i<=date('Y');$i++){
        echo "<option value='".$i."'>$i</option>";
    }
}
function Calendario($numeroDiasMes, $diaSemana){
    for ($i=2;$i<=$numeroDiasMes;$i++){
        echo"<tr>";
        $i--;
        for($j=1;$j<=7;$j++){
            if(($i<=$j && $j<$diaSemana) || $i>$numeroDiasMes){
                echo "<td>*</td>";
            }else{
                    echo"<td>$i</td>";
                    $i++;
                    
            }
        }echo"</tr>";
        }
    }

?>

</body>
</html>