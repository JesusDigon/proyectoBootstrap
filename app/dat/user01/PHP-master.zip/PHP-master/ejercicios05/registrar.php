<!DOCTYPE unspecified PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>5.2</title>
<meta charset="UTF-8"/>
</head>
<body>
<?php 
$respuesta= <<<Marca
    <h1>REGISTRO DE NUEVO USUARIO: </h1>
    <form action='registrar.php' method='POST'>
    <p>Introduzca el nombre de usuario: <input type='text' name='user'/></p>
    <p>Correo electronico: <input type='email' name='email'/></p>
    <p>Introduzca la contraseña: <input type='password' name='pass' /></p>
    <p>Introduzca la contraseña: <input type='password' name='pass2' /></p>
    <input type='submit' value='enviar'/></form>
Marca;
$respuesta1="";
if($_SERVER['REQUEST_METHOD']=='GET'){
    echo $respuesta;
}else{
    $nombre=$_POST['user'];
    $contraseña=$_POST['pass'];
    $contraseña2=$_POST['pass2'];
    $mail=$_POST['email'];
    if(CamposVacios($nombre, $contraseña,$contraseña2, $mail, $respuesta1) && 
        ContraseñasIguales($contraseña, $contraseña2, $respuesta1) &&
        ContraseñaSegura($contraseña, $respuesta1) && 
        ComprobarMail($mail, $respuesta1)){
            echo "<h1>Bienvenido $nombre";
    }else{
        echo $respuesta.$respuesta1;
        
         
    
    
        }
    
}
function ComprobarMail($mail,$respuesta1 ){
    if(filter_var($mail, FILTER_VALIDATE_EMAIL)){
        return true;
    }else{
        $respuesta1="Debe introducir una direccion de email válida.";
    }
}
function CamposVacios($nombre,$contraseña,$contraseña2,$mail, &$respuesta1){
    if($nombre===""||$contraseña===""||$contraseña2===""||$mail===""){

        $respuesta1="Debe rellenar todos los campos.";
        return false;
    }else{
         return true;   
        }
}
function ContraseñasIguales($contraeña, $contraseña2, &$respuesta1){
    if ($contraeña===$contraseña2){
        return true;
    }else{
        $respuesta1= "Las contraseñas no coinciden.";
        return false;
    }
}
function ContraseñaSegura($contraseña, &$respuesta1){
    if(strlen($contraseña)>=8){
    if(ctype_upper($contraseña)||ctype_lower($contraseña)){
        $respuesta1="La contraseña debe contener al menos una minúscula y una mayúscula.";
        return false;
    }elseif(ctype_alpha($contraseña)){
        $respuesta1="La contraseña debe contener algún carácter numérico";
        return false;
    }elseif(ctype_alnum($contraseña)){
        $respuesta1="La contraseña debe contener algún carácter no alfanumérico";
        return false;
    }else{
        return true;
    }
    }else{
        $respuesta1="La contraseña debe contener al menos 8 carácteres.";
        return false;
    }
}

  ?>


</body></html>

