<?php 
session_start();

if(!isset($_SESSION['palabrasecreta'])){
    $_SESSION['palabrasecreta']= ElegirPalabra();
    $_SESSION['palabrausuario']= "";
    $_SESSION['fallos']= 0;
}else{
   
    if(isset($_GET['letra'])){
        
        $_SESSION['palabrausuario'].=$_GET['letra'];
        ComprobarCadena();
        
}
}

print_r($_SESSION);
print_r($_GET);
echo GenerarPalabraConHuecos($_SESSION['palabrasecreta'] , $_SESSION['palabrausuario']);
?>

<html>
<head>
<meta charset="UTF-8">
<title>Ahorcado</title>
</head>
<body>
<h1>Juego del Ahorcado</h1>
<h2>PALABRA: <?php echo GenerarPalabraConHuecos($_SESSION['palabrasecreta'], $_SESSION['palabrausuario']);?></h2>
<h2>Ha cometido <?php echo $_SESSION['fallos'];?> fallos</h2>
<h2>Introduzca una letra: <form><input name="letra" type="text" maxlength="1"><input type="submit" name="enviar" value="enviar"></form></h2>
</body>
</html>

<?php

function ElegirPalabra(){
   static $tpalabras=['Madrid', 'Sevilla', 'Malaga', 'Murcia', 'Mallorca', 'Menorca'];
   $palabra=$tpalabras[rand(0,sizeof($tpalabras))];
   return $palabra;
}
function GenerarPalabraConHuecos($palabra, $palabra1){
    $resu="";
    for($i=0;$i<strlen($palabra);$i++){
        if(strpos($palabra, $palabra1[$i])===false){
            $resu.="-";
            
        }else{
            $resu[strpos($palabra,$palabra1)]=$palabra[$i];
        }
    }
    
 
    return $resu;
}
function ComprobarCadena(){
    
}
$inactividad=30;
if(isset($_SESSION['timeout'])){
    $sesionTTL= time()- $_SESSION['timeout'];
    if($sesionTTL>$inactividad){
        session_destroy();
        header("Refresh:0");
    }
}
$_SESSION['timeout']= time();

?>

