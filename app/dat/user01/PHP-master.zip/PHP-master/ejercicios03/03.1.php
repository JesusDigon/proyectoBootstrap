<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
	<title>php 3.1</title>
	<style type="text/css">
        table, td{
            border: solid 2px;
            border-collapse: collapse;
        }
	</style>
</head>
<body>
<?php 
$t1=[];
$maximo=0;
$minimo=11;
$masRep=0;
function RellenarArray(&$t1){
    for ($i=0;$i<20;$i++){
        $aleatorio=rand(1,10);
        $t1[$i]=$aleatorio;
    }
}
function obtenerMaximo($maximo, $t1){
    foreach($t1 as $valor) {
    if($maximo<$valor){
            $maximo=$valor;
        }
    }
    return $maximo;
}
function obtenerMinimo($minimo, $t1){
    foreach ($t1 as $valor){ 
    if($minimo>$valor){
            $minimo=$valor;
        }
    }
    return $minimo;
}
function obtenerRepetido($masRep, $t1){
    
    for ($i=0;$i<sizeof($t1);$i++){
            foreach ($t1 as $valor){
                if ($valor==$t1[$i]){
                    $masRep++;
                    $num1=$t1[$i];
                $tabla =array ($num1 => $masRep) ;
            }
            }
        }
    
    foreach($tabla as $clave => $valor){
        $rep=0;
        if ($valor>$rep){
            $rep=$valor;
            $masRep=$clave;
        }
    }
    return $masRep;
}
function mostrarEnTabla($t1,$maximo,$minimo,$masRep){
    echo "<table>";
    foreach ($t1 as $valor){
        echo "<tr><td>$valor</td></tr>";
    }
    echo "</table>";
}
RellenarArray($t1);
$maximo=obtenerMaximo($maximo, $t1);
$minimo= obtenerMinimo($minimo, $t1);
$masRep=obtenerRepetido($masRep, $t1);
mostrarEnTabla($t1,$maximo,$minimo,$masRep);
   echo "El numero mas grande es: $maximo, el mas pequeño:  $minimo, y el que mas veces aparece: $masRep";
    ?>

	

</body>
</html>