<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
<title>php 3.1</title>
<style type="text/css">
table, td, th{
    color:blue;
    height:2em;
    border:solid black 2px;
    border-collapse: collapse;
}
</style>
</head>
<body>
<?php
$tabla=[];
$contador=0;
while($contador<=5){
    $valor=rand(1,49);
    if (!in_array( $valor, $tabla)){
      $tabla[$contador]=$valor; 
      $contador++;
    }else{
        $valor=rand(1,49);
    }
}
$reintegro=$tabla[5];
unset($tabla[5]);
sort($tabla);
echo "<table><tr>";
foreach($tabla as $valor){
    echo "<td>$valor</td>";
}
echo "<td>El complementario es: $reintegro</td></tr>";

?>
</body>
</html>
