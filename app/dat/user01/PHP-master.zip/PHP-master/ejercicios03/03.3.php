<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
	<title>php 3.3</title>
	<style type="text/css">
      
	</style>
</head>
<body>
<?php 
    
$medios= array("El Mundo" => "https://www.elmundo.es/", "El Pais" => "https://elpais.com/", "ABC" => "https://www.abc.es/", "OkDiario" => "https://okdiario.com", "El Periodico" => "https://www.elperiodico.com/es/");
 function CrearListaMedios($medios){
     echo "<list><ul>";
     foreach ($medios as $clave => $valor){
         echo "<li><a href=".$valor." target="."_blank".">$clave<li>";
     }
     echo "</ul></list>";
 } 
function MostrarEnlaceAlAzar($medios){
    $aleatorio=rand(1,5);
    $contador=1;
    while(true){
        foreach($medios as $clave => $valor){
            if ($contador == $aleatorio){
                echo "<p>El medio recomendado es: <a href=".$valor." target="."_blank>$clave</p>";
                break;
            }else{
                $contador++;
            }
        }
        break;
    }
        
}
    MostrarEnlaceAlAzar($medios);
    ?>
	

</body>
</html>