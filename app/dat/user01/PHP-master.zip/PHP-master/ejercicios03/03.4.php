
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
<title>php 3.1</title>
<style type="text/css">
table, td, th{
    width:1em;
    height:1em;
    border:solid 2px;
    border-collapse: collapse;
}
</style>
</head>
<body>
<?php
$tabla= ["Ciclismo" => "imagenes/logoCiclismo.jpeg", "Crossfit" => "imagenes/crossfit.jpeg",
    "Trail" => "imagenes/logoTrail.png","Halterofilia" => "imagenes/logoHaltero.png",
    "Karate" => "imagenes/logoKarate.png"];
function MostrarTabla($tabla, $filas){
    echo "<table><th>Deportre</th><th>Imagen</th>";
   
      
     foreach($tabla as $clave => $valor){
            echo "<tr><td>$clave</td><td><img src="."'$valor'".' width="75em" height="75em"</td><tr>';
            }
           
    
}
MostrarTabla($tabla, sizeof($tabla));
?>
</body>
</html>