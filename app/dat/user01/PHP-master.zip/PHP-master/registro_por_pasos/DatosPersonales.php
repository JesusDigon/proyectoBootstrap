<html>
<head>
<title>Datos Personales</title>
<style type="text/css">
#form{
margin-top:2em;
width:100%
}
</style>
</head>
<body>
</body>
<div id="form">
<form action="index.php">
<fieldset>
<legend>Datos Personales</legend>
Nombre: <input type="text" name="nombre" value="<?=(isset($nombre))?strip_tags($nombre):''?>">
Apellidos: <input type="text" name="apellidos" value="<?=(isset($apellidos))?strip_tags($apellidos):''?>"><br>
Fecha de nacimiento: <input type="date" name="nacimiento" value="<?=(isset($nacimiento))?strip_tags($nacimiento):''?>"><br>
Género: <input type="radio" name="genero" value="Mujer">Mujer
<input type="radio" name="genero" value="Hombre">Hombre
<input type="radio" name="genero" value="Otro">Otro<br>
Casado <input type="checkbox" name="casado" value="casado"> 
Hijos <input type="checkbox" name="hijos" value="hijos"><br>
Nacionalidad: <select multiple="multiple" name="nacionalidad[]">
<option value="Española" <?=(in_array("Española",$nacionalidad))?'selected="selected"':''?>>Española
<option value="Francesa" <?=(in_array("Francesa",$nacionalidad))?'selected="selected"':''?>>Francesa
<option value="Italiana" <?=(in_array("Italiana",$nacionalidad))?'selected="selected"':''?>>Italiana
</select><br>

<input type="submit" name="orden" value="siguiente">
</fieldset>
</form>
</div>

</html>

<?php
