<html>
<head>
<title>Datos Bancarios</title>
<style type="text/css">
#form{
margin-top:2em;
width:100%
}
</style>
</head>
<body>
</body>
<div id="form">
<form action="index.php">
<fieldset>
<legend>Datos Bancarios</legend>
Cuenta Corriente: <input type="text" name="cuenta" value="<?=(isset($cuenta))?strip_tags($cuenta):''?>"><br>

<input type="submit" name="orden" value="anterior">
<input type="submit" name="orden" value="siguiente">
</fieldset>
</form>
</div>

</html>
