<html>
<head>

<style>
#Nav{
width:100%;
height: 20%;
}
img{
width:10%;

}
</style>
</head>
<body>
<div id="Nav">
<a href="index.php?nav=1"><img src="img/Number-1-icon.png"></a> 
<a href="index.php?nav=2"><img src="img/Number-2-icon.png"></a> 
<a href="index.php?nav=3"><img src="img/Number-3-icon.png"></a> 
<a href="index.php?nav=4"><img src="img/checkered-flag-icon.png"></a> 
</div>
</body>
</html>
