<?php
include_once 'Navegacion.php';
session_start();
$ListaVar=['nombre', 'apellidos','dpto', 'puesto', 'cuenta' ];
if(!isset($_SESSION['paso'])){
    $_SESSION['paso']=1;
    $_SESSION['valores']=[];
    foreach ($ListaVar as $clave => $valor){
        ${$valor}=" ";
    }  
}
foreach ($_REQUEST as $clave => $valor){
    $_SESSION['valores'][$clave]=$valor;
}
foreach ($_SESSION['valores'] as $clave => $valor){
    ${$clave}=$valor;
}
if(isset($_REQUEST['orden'])){
    switch ($_REQUEST['orden']){
        case 'siguiente':
            $_SESSION['paso']++;
            break;
        case 'anterior':
            $_SESSION['paso']--;
    }
}

if(isset($_REQUEST['nav'])){
    
    switch ($_REQUEST['nav']){
        case 1:
            $_SESSION['paso']=1;
            include_once 'DatosPersonales.php';
            break;
        case 2:
            $_SESSION['paso']=2;
            include_once 'DatosProfesionales.php';       
            break;
        case 3:
            $_SESSION['paso']=3;
            include_once 'DatosBancarios.php';            
            break;
        case 4:
            $_SESSION['paso']=4;
            include_once 'Resumen.php';          
            break;
    }
}
switch ($_SESSION['paso']){
    case 1:
        include_once 'DatosPersonales.php';
        break;
    case 2:
        include_once 'DatosProfesionales.php';
        break;
    case 3:
        include_once 'DatosBancarios.php';
        break;
    case 4:
        include_once 'Resumen.php';
        break;
}
    

print_r($_SESSION);
print_r($_REQUEST);
echo $nombre ;
?>

