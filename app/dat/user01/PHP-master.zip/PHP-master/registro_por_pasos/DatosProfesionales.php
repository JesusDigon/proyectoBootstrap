
<html>
<head>
<title>Datos Profesionales</title>
<style type="text/css">
#form{
margin-top:2em;
width:100%
}
</style>
</head>
<body>
</body>
<div id="form">
<form action="index.php">
<fieldset>
<legend>Datos Profesionales</legend>
Departamento: <input type="text" name="dpto" value="<?=(isset($dpto))?strip_tags($dpto):''?>"><br>
Puesto: <input type="text" name="puesto" value="<?=(isset($puesto))?strip_tags($puesto):''?>"><br>
<input type="submit" name="orden" value="anterior">
<input type="submit" name="orden" value="siguiente">
</fieldset>
</form>
</div>

</html>

