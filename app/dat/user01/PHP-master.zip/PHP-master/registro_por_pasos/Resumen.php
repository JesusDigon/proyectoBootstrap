<html>
<head>
<title>Resumen</title>
</head>
<body>
<div id="form">
<form action="index.php">
<fieldset>
<legend>Datos Personales</legend>
Nombre: <?=(isset($nombre))?strip_tags($nombre):''?><br>
Apellidos: <?=(isset($apellidos))?strip_tags($apellidos):''?><br>
departamento: <?=(isset($dpto))?strip_tags($dpto):''?><br>
Puesto: <?=(isset($puesto))?strip_tags($puesto):''?><br>
Cuenta Corriente: <?=(isset($cuenta))?strip_tags($cuenta):''?><br>
<a href="index.php?nav=1">Volver al principio</a>
</fieldset>
</form>
</div>
</body>
</html>

