<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
	<title>php 2</title>
	<style type="text/css">
	p {text-align: center;}
	</style>
</head>
<body>
	<?php
		$num1=rand(1,10);
		for ($i=1; $i<=$num1; $i++){
			
				echo "<p>*";
				for ($j=2; $j<=$i;$j++){
				echo "**";
				}
				echo "</p>";
			}

		?>
</body>
</html>