<HTML>
<HEAD>
</HEAD>
<BODY>
	<H1>Hola Mundo</H1>
	<HR>
	<?PHP 
		$NOMBRE = "Jaime";
		$num1 = 34;
		$num2 = 26;
		echo $num1 * $num2;
		echo "<br>";
		echo $NOMBRE;
	?>
	<HR>
</BODY>
</HTML>