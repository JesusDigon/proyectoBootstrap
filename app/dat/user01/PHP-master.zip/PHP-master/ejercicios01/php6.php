<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
	<title>php 6</title>
	<style type="text/css">
		h1{
			background-color: blue;
		}
	</style>
</head>
<body>
	<h1>TABLA DE MULTIPLICAR</h1>
	<?php 
	$num1= rand(1,10);
	?>

	<table>
		<th><?php echo "tabla del $num1"; ?></th>
		<th></th>
		
	</table>

</body>
</html>