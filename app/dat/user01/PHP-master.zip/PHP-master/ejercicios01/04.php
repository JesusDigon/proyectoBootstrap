<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
	<title>php 4</title>
	
</head>
<body>
	<?php
		$time_start = microtime(true);
		$contador=0;
		$contador_6=0;
		while($contador_6 < 3){
			$num1=rand(1,10);
			$contador++;
			if($num1==6){
				$contador_6++;	
			}else{
			    $contador_6=0;
				}
						
			}
		$time_end= microtime(true);
		$tiempo= $time_end - $time_start;
		echo "Han salido tres 6 seguidos tras generar ". $contador. " numeros aleatorios, en ".$tiempo. " segundos.";

		?>
</body>
</html>
