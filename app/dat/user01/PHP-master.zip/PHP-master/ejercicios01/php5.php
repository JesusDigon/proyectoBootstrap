<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
	<title>php 1</title>
	<style type="text/css">
		table, tr, td, th{
			border-color: grey;
			border-style: solid;
			border-collapse: collapse;
		}
		td.right{
			text-align: right;
		}
		td.left{
			text-align: left;
		}
		tr:nth-child(odd) {
	
   		background-color:#f2f2f2;
		}
	
		tr:nth-child(even) {
	
    	background-color:#fbfbfb;
	
		}
	</style>
</head>
<body>
	<?php
		$num1=rand(1,10);
		$num2=rand(1,10);
		$suma=$num1 + $num2;
		$resta=$num1 - $num2;
		$multi=$num1 * $num2;
		$divi=$num1 / $num2;
		$pot= $num1;
		for ($i=1; $i<$num2; $i++){
				$pot*=$num1;
			};
		?>
	<table>
		<th>operación</th>
		<th>resultado</th>
		<tr>
			<td class="left"><?php echo "$num1 + $num2"?></td>
			<td class="right"><?php echo "$suma"?></td>
		</tr>
		<tr>
			<td class="left"><?php echo "$num1 - $num2"?></td>
			<td class="right"><?php echo "$resta"?></td>
		</tr>
		<tr>
			<td class="left"><?php echo "$num1 * $num2"?></td>
			<td class="right"><?php echo "$multi"?></td>
		</tr>
		<tr>
			<td class="left"><?php echo "$num1 / $num2"?></td>
			<td class="right"><?php echo "$divi"?></td>
		</tr>
		<tr>
			<td class="left"><?php echo "$num1 ^ $num2"?></td>
			<td class="right"><?php echo "$pot"?></td>
		</tr>
	</table>

</body>
</html>