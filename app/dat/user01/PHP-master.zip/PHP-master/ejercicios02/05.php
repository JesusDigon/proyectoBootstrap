<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
<title>php 2.4</title>
</head>
<body>
<?php
$filas=rand(1,10);
$columnas=rand(1,10);
$borde=rand(1,5);
$contenido="pruebaTabla";
    function GenerarHtmlTable($filas, $columnas, $borde, $contenido){
        echo "<table border=",$borde,">";
        for($i=0;$i<=$filas;$i++){
            echo "<tr>";
            for ($k=1;$k<=$columnas;$k++){
                echo "<td>",$contenido,"</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    }
GenerarHtmlTable($filas, $columnas, $borde, $contenido);

?>

</body>
</html>

