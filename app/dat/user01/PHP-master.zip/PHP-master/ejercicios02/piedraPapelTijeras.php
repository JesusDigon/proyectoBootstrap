<html>
<head>
<title>Online PHP Script Execution</title>
</head>
<body>
    <?php 
  
function jugadaJ1($jugador1){
    switch($jugador1){
        case 1: return "&#x1F91C;";
        break;
        case 2: return "&#x1F91A;";
        break;
        case 3: return "&#x1F596;";
        break;
        }
    }
function jugadaJ2($jugador2){
    switch($jugador2){
        case 1: return "&#x1F91B;";
        break;
        case 2: return "&#x1F91A;";
        break;
        case 3: return "&#x1F596;";
        break;
        }
    }
function resolverGanador($jugador1, $jugador2){
        if($jugador1 == $jugador2){
            echo "Los dos jugadores empataron.";        
    }else if(($jugador1==1 && jugador2==3) || ($jugador1==2 && $jugador2==1)||($jugador1==3 && $jugador2==2)){
        echo "Gana el jugador 1.";
    }else{
        echo "Gana el jugador 2.";
    }
}
      $jugador1=rand(1,3);
    $jugador2=rand(1,3);
        ?>
    
    <h1>¡Piedra, papel, tijera!</h1>

    <p>Actualice la página para mostrar otra partida.</p>

    <table>
      <tr>
        <th>Jugador 1</th>
        <th>Jugador 2</th>
      </tr>
      <tr>
          <td><span style="font-size: 7rem"><?php echo jugadaJ1($jugador1); ?></span></td>
        <td><span style="font-size: 7rem"><?php echo jugadaJ2($jugador2); ?></span></td>
      </tr>
      <tr>
        <th colspan="2"><?php echo resolverGanador($jugador1, $jugador2); ?></th>
      </tr>
    </table>
    
</body>
</html>