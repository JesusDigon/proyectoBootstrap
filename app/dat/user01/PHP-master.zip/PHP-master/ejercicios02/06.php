<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
	<title>php 2</title>
	<style type="text/css">
	body{
	text-aling:center;
	font:bold 200% monospace;
	}
	</style>
</head>
<body>
<?php
$tamaño= rand(1,10);
for ($i=0;$i<2;$i++){
    
    for ($k=0;$k<$tamaño;$k++){
        echo "****&nbsp";
       
    }
    echo "<br>";
   

}
for ($i=0;$i<$tamaño-1;$i++){
    echo "*****";
}
echo"****";
?>
</body>
</html>