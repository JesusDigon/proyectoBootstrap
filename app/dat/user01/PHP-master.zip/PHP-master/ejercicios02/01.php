<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
	<title>php 2</title>
	<style type="text/css">
	</style>
</head>
<body>
	<?php
    $A=rand(1,10);
    $B=rand(1,10);
    $C=0;
    function ElMayor($A,$B,&$C) {
        if($A>$B):
        $C=$A;
        elseif($B>$A):
        $C=$B;
        else:
        $C=0;
        endif;
    }
    ElMayor($A, $B, $C);
    echo "el primer numero es: ", $A;
    echo "el segundo numero es: ", $B;
    echo "El mas grande es: " , $C;
		?>
</body>
</html>