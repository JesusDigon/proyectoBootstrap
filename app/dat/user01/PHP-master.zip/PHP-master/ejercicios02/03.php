	<?php
	   require_once 'funcionesPHPRef.php';
		$num1=rand(1,10);
		$num2=rand(1,10);
		$valorSuma=0;
		$valorResta=0;
		$valorMulti=0;
		$valorDiv=0;
		$valorPot=1;
		suma($num1,$num2, $valorSuma);
		resta($num1,$num2, $valorResta);
		multi($num1,$num2, $valorMulti);
		divi($num1,$num2, $valorDiv);
		pot($num1,$num2, $valorPot);
		
		echo "<p> $num1 + $num2 = " , $valorSuma, "</p>";
		echo "<p> $num1 - $num2 = ", $valorResta, "</p>";
		echo "<p> $num1 * $num2 = ", $valorMulti, "</p>";
		echo "<p> $num1 / $num2 = ", $valorDiv , "</p>";
		echo "<p> $num1 ** $num2 = ", $valorPot, "</p>";

		?>