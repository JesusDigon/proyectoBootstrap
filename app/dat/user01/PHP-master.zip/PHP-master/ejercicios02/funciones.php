<?php

function suma($num1,$num2){
    return $num1-$num2;
}

function resta($num1,$num2){
    return $num1 - $num2;
}
function multi($num1,$num2){
    return $num1 * $num2;
}
function divi($num1,$num2){
    return $num1 / $num2;
}
function pot($num1,$num2){
    for ($i=1; $i<$num2; $i++){
        $pot*=$num1;
}
}

    ?>