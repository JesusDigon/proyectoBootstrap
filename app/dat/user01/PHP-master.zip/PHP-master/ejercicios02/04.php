
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
<title>php 2.4</title>
<style type="text/css">
    table,  td {
    border: solid;
    border-collapse: collapse;
    }
    th{
    background-color: black;
    color: white;
    text-align: center;
    width: auto;
    padding:3px 30px 3px 30px;
    
    }
    td.derecha{
    text-align: rigth;
    }
</style>

</head>
<body>
<table>
<th colspan="2">Generacion de 50 valores aleatorios</th>
<?php 
$suma=0;
$media=0;
$maximo=0;
$minimo=100;
for ($i=0;$i<=50;$i++){
    $aleatorio=rand(1,100);
    $suma+=$aleatorio;
    if($aleatorio>$maximo){
        $maximo=$aleatorio;
    }
    if($aleatorio<$minimo){
        $minimo=$aleatorio;
    }
}
$media=$suma/50;
echo "<tr>
        <td>Minimo</td>
        <td class=\"derecha\">",$minimo,"</td>
      </tr>
      <tr>
        <td>Maximo</td>  
        <td class=\"derecha\">",$maximo,"</td>
      </tr>
      <tr>
        <td>Media</td>
        <td class=\"derecha\">",$media,"</td>
    </tr>";
?>

</table>

</body>
</html>