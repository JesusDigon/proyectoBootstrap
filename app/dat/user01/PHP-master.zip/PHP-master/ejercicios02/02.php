<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
	<title>php 1</title>
</head>
<body>
	<?php
	   require_once 'funciones.php';
		$num1=rand(1,10);
		$num2=rand(1,10);
		
		echo "<p> $num1 + $num2 = " , suma($num1,$num2); "</p>";
		echo "<p> $num1 - $num2 = ", resta($num1,$num2); "</p>";
		echo "<p> $num1 * $num2 = ", multi($num1,$num2); "</p>";
		echo "<p> $num1 / $num2 = ", divi($num1,$num2);  "</p>";
		echo "<p> $num1 ** $num2 = ", pot($num1,$num2);  "</p>";

		?>
</body>
</html>