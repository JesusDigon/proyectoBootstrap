<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Contet-Type" content="text/html;charset=iso-8859-1" />
	<title>php 2</title>
	<style type="text/css">
	body{
	text-aling:center;
	font:bold 300% monospace;
	}
	table{
	width:5em;
	height:5em;
	}

	}
	</style>
</head>
<body>
<?php
function GenerarTabla($filas,$columnas, $rojo, $verde, $azul){
    echo "<table border="."2".">";
    for ($i=0;$i<=$filas;$i++){
        echo "<tr>";
        for ($k=0;$k<=$columnas;$k++){
            echo "<td style="."background-color:rgb(".$rojo.",".$verde.",".$azul.">";
            if($azul<255){
                $azul++;
            }elseif($verde<255){
                $verde++;
            }elseif($rojo<255){
                $rojo++;
            }else{
                $azul=0;
                $verde=0;
                $rojo=0;
            }
            
        }
    }
    echo "</table>";
}
$rojo=rand(0,255);
$verde=rand(0,255);
$azul=rand(0,255);


$filas=10;
$columnas=10;


GenerarTabla($filas, $columnas, $rojo, $verde, $azul) ;
?>
</body>
</html>