<html>
<head>
<style type="text/css">
    table, tr, td{
        border: solid red 2px;    
        border-collapse:collapse;
    }
    
</style>
</head>
<body>
<?php
$tabla=[];
function GenerarArray(){
    $tabla=[];
    $min=1;
    $max=9;
    for ($i=0;$i<27;$i++){
        for($j=0;$j<3;$j++){
        $tabla[$i]= rand($min, $max);
        $ale=rand($min, $max);
        while(in_array($ale, $tabla)){
          $ale=rand($min,$max);  
        }
            $i++;
            $tabla[$i]=$ale;
        }
            
        if($min==1){
            $min+=9;
            $max+=10;
        }else if($max==79){
            $max+=11;
            $min+=10;
        }else{
        $min+=10;
        $max+=10;
        }
    }
        return $tabla;
    }
    

  $tabla=GenerarArray();
  sort($tabla);
  $posicionAborrar=[];
  function ArrayPosicion(&$posicionAborrar) {
      for($i=0;$i<3;$i++){
          $posicion=rand(0,27);
          while(in_array($posicion,$posicionAborrar) || in_array(($posicion + 1) ,$posicionAborrar) || in_array(($posicion -1) ,$posicionAborrar)){
              $posicion=rand(0,27);
          }
          $posicionAborrar[$i]=$posicion;
      }
  }
  ArrayPosicion($posicionAborrar);
  function cambiarArray($posicionAborrar, &$tabla){
      for($i=0;$i<3;$i++){
          $tabla[$posicionAborrar[$i]]=0;
      }
  }
cambiarArray($posicionAborrar, $tabla);
  function Mostrar($tabla){
      $cont=0;
      echo "<table><tr>";
      for($j=0;$j<3;$j++){
      for ($i=0;$i<9;$i++) {
          if($tabla[$cont]==0){
              echo "<td></td>";
          }else{
          echo "<td>".$tabla[$cont]."</td>";  
          }
          $cont+=3;
          if($cont==24){
              $cont=1;
          }elseif($cont==25){
              $cont=2;
          }
          
      }
      echo "</tr>";
     
      }echo "</table>";
  }
  Mostrar($tabla);
?>
</body>
</html>