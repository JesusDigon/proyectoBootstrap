<?php
include_once 'app/config.php';

//Carga los datos de un fichoro de texto
function cargarDatostxt(){
    // Si no existe lo creo
    $tabla=[]; 
    if (!is_readable(FILEUSER) ){
        // El directorio donde se crea tiene que tener permisos adecuados
        $fich = @fopen(FILEUSER,"w") or die ("Error al crear el fichero.");
        fclose($fich);
    }
    $fich = @fopen(FILEUSER, 'r') or die("ERROR al abrir fichero de usuarios"); // abrimos el fichero para lectura
    
    while ($linea = fgets($fich)) {
        $partes = explode('|', trim($linea));
        // Escribimos la correspondiente fila en tabla
        $tabla[]= [ $partes[0],$partes[1],$partes[2],$partes[3]];
        }
    fclose($fich);
    return $tabla;
}

function mostrarDatos (){
    echo "<table>\n";
     // Identificador de la tabla
    // Generamos la cabecera de la tabla
    echo "<tr><th>usuario</th><th>login</th><th>pasword</th></tr>\n";
    $auto = $_SERVER['PHP_SELF'];
    $id=0;
    $nusuarios = count($_SESSION['tuser']);
    for($id=0; $id< $nusuarios ; $id++){
        echo "<tr>";
        $datosusuario = $_SESSION['tuser'][$id];
        for ($j=0; $j < CAMPOSVISIBLES; $j++){
            echo "<td>$datosusuario[$j]</td>";
        }
        echo "<td><a href=\"#\" onclick=\"confirmarBorrar('$datosusuario[0]',$id);\" >Borrar</a></td>\n";
        echo "<td><a href=\"".$auto."?orden=Modificar&id=$id\">Modificar</a></td>\n";
        echo "<td><a href=\"".$auto."?orden=Detalles&id=$id\" >Detalles</a></td>\n";
        echo "</tr>\n";
        
    }
    echo "</table>";
}

function accionBorrar($id){
    unset($_SESSION['tuser'][$id]);
    $_SESSION['tuser']=array_values($_SESSION['tuser']);
    include_once 'principal.php';
}

function mostrarseleccionado($id){
    foreach($_SESSION['tuser'] as $clave => $valor){
        if($clave==$id){
            $usuario=$_SESSION['tuser'][$clave];
            $_GET['usuario']=$usuario;
        }
    }
    $_SESSION['id']=$id;
    include_once "formulario.php";
}

function guardarFichero(){
    $fich = @fopen(FILEUSER,"w") or die ("Error al abrir el fichero.");
    for($i=0;$i<sizeof($_SESSION['tuser']);$i++){
        fwrite($fich, implode('|', $_SESSION['tuser'][$i]).PHP_EOL);
    }
    fclose($fich);
    
}
function comprobarlogin($orden){
    for($i=0;$i<sizeof($_SESSION['tuser']);$i++){
        foreach($_SESSION['tuser'][$i] as $clave => $valor){
            if($clave==1 && $valor==$_POST['login']){
                if($orden=='Modificar'){
                $_GET['orden']='Modificar';
                }else{
                    $_GET['orden']='Nuevo';
                }
                mostrarseleccionado($_SESSION['id']);
                echo "<p>El login ya existe en la aplicación, por favor eliga otro</p>" ;
                return false;
            }
        }
        }
        return true;
}
function accionGuardar($orden){
  if(comprobarlogin($orden)){
    $_SESSION['tuser'][]=[filtrado($_POST['user']),filtrado($_POST['login']),filtrado($_POST['password']),filtrado($_POST['desc'])];
    include_once 'principal.php';
}
}
function filtrado($datos){
    $datos=trim($datos);
    $datos=stripcslashes($datos);
    $datos=htmlspecialchars($datos);
    return $datos;
}
function accionModificar($orden){
    
    $_SESSION['tuser'][$_SESSION['id']]=[filtrado($_POST['user']),filtrado($_POST['login']),filtrado($_POST['password']),filtrado($_POST['desc'])];
    include_once 'app/principal.php';

}
?>
