<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>CRUD DE USUARIOS</title>
<link href="web/default.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="web/js/funciones.js"></script>
</head>
<body>
<div id="container" style="width: 600px;">
<div id="header">
<h1>GESTIÓN DE USUARIOS versión 1.0</h1>
</div>
<div id="content">


<form name="form" action="index.php" method="POST">
<p>Usuario: <input type="text" name="user" value="<?=($_GET['orden']=='Nuevo')?'' : $usuario[0]?>" <?=($_GET['orden']=='Detalles')? 'readonly' : ''?>></p>
<p>Login: <input type="text" name="login" value="<?=($_GET['orden']=='Nuevo')?'' : $usuario[1]?>" <?=($_GET['orden']=='Nuevo')? '' : 'readonly'?>></p>
<p>Contraseña: <input type="password" name="password" value="<?=($_GET['orden']=='Nuevo')?'' : $usuario[2]?>" <?=($_GET['orden']=='Detalles')? 'readonly' : ''?>></p>
<p>Descripción: <input type="text" name="desc" value="<?=($_GET['orden']=='Nuevo')?'' : $usuario[3]?>" <?=($_GET['orden']=='Detalles')? 'readonly' : ''?>></p>
<input type="submit" name="orden" value="<?=($_GET['orden']=='Modificar' )?'modificar': 'guardar'?>" <?=($_GET['orden']=='Detalles')?'disabled':''?>>
<input type="submit" name="orden" value="cancelar">
</form>
</div>
</div>
</body>
