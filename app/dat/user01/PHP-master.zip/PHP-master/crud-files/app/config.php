<?php 
define('CAMPOSVISIBLES',3);
define('FILEUSER','dat/usuarios.txt');
?>