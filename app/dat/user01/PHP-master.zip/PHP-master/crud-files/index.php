<?php
session_start();
include_once 'app/funciones.php';

// Tabla de usuarios
if (!isset ($_SESSION['tuser'])){
    $_SESSION['tuser'] = cargarDatostxt();
  
}


if ($_SERVER['REQUEST_METHOD'] == "GET" ){
    
    if ( isset($_GET['orden'])){
        switch ($_GET['orden']) {
            case "Nuevo"    : include_once 'app/formulario.php'; break;
            case "Borrar"   : accionBorrar($_GET['id']); break;
            case "Modificar": mostrarseleccionado($_GET['id']); break;
            case "Detalles" : mostrarseleccionado($_GET['id']); break;
            case "Terminar" : guardarFichero();session_destroy();echo"<h1>¡Hasta pronto!</h1>" ;break;
        }
    }else{
        include_once 'app/principal.php';
 }
 }
 if($_SERVER['REQUEST_METHOD']== "POST"){
        if(isset($_POST['orden'])){
            switch($_POST['orden']){
                case 'guardar': accionGuardar('guardar');break;
                case 'modificar'; accionModificar('Modificar');break;
                case 'cancelar': include_once 'app/principal.php'; 
            }
                 
        }

            
}else{
       // include_once 'app/principal.php';
    }
    
    


