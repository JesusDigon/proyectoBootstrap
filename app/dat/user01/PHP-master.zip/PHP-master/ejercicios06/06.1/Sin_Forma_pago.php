<html> 
    <head> 
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
        <title>Forma de pago</title> 
    </head> 
    <body> 
      
	  	<h2> NO TIENE FORMA DE PAGO ASIGNADA </h2> <br>
        <h2>SELECCIONE UNA NUEVA TARJETA DE CREDITO </h2><br> 
        <a href='index?nuevatarjeta=cashu'><img  src='imagenes/cashu.gif' /></a>&ensp; 
        <a href='index.php?nuevatarjeta=cirrus1'><img  src='imagenes/cirrus1.gif' /></a>&ensp; 
        <a href='index.php?nuevatarjeta=dinersclub'><img  src='imagenes/dinersclub.gif' /></a>&ensp; 
        <a href='index.php?nuevatarjeta=mastercard1'><img  src='imagenes/mastercard1.gif'/></a>&ensp; 
        <a href='index.php?nuevatarjeta=paypal'><img  src='imagenes/paypal.gif' /></a>&ensp; 
        <a href='index.php?nuevatarjeta=visa1'><img  src='imagenes/visa1.gif' /></a>&ensp; 
        <a href='index.php?nuevatarjeta=visa_electron'><img  src='imagenes/visa_electron.gif'/></a>  

      
    </body> 
</html>