<?php 


session_start();
if(isset($_GET['nuevatarjeta'])){
$tarjeta=$_GET['nuevatarjeta'];
$_SESSION['tarjeta']=$tarjeta;
}
$inactividad=30;
if(isset($_SESSION['timeout'])){
    $sesionTTL= time()- $_SESSION['timeout'];
    if($sesionTTL>$inactividad){
        session_destroy();
        header("Location: Sin_Forma_pago.php");
    }
}
$_SESSION['timeout']= time();
if(!isset($_SESSION['tarjeta'])){
    include_once 'Sin_Forma_pago.php';
}else{
    include_once 'Forma_pago.php';
}
?>

