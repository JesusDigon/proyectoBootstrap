<?php 

if(isset($_GET['nuevatarjeta'])){
    $tarjeta=$_GET['nuevatarjeta'];
    setcookie('tarjeta', $tarjeta, time() + 3*24*3600);
    include_once 'Forma_pago.php';
}else{
    if (isset($_COOKIE['tarjeta'])){

    include_once 'Forma_pago.php';
    header("Refresh:0");
    exit;
    } else{
        
    
    include_once 'Sin_Forma_pago.php';
}
}






?>

