<?php
print_r($_REQUEST);
var_dump($_REQUEST);
?>