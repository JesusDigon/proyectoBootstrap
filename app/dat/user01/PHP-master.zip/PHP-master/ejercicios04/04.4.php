<!DOCTYPE unspecified PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>4.4</title>
<style>
h1{
    background-color:blue;
}
</style>
</head>
<body>

<h1>Procesando formulario</h1>
<p>nombre: <?php echo $_REQUEST['nombre']?></p>
<p>Contraseña: <?php echo $_REQUEST['pass']?></p>
<p>Semaforo: <?php echo $_REQUEST['radio']?></p>
<p>Publicidad: <?php 
if (isset($_REQUEST['publi'])){
echo "Si";
}else{
echo"no";
}?></p>
<p>idiomas: <?php 
if (isset($_REQUEST['ingles'])){echo " Ingles ";} 
if (isset($_REQUEST['aleman'])){echo " Aleman ";}
if (isset($_REQUEST['frances'])){echo " frances ";}
?></p>
<p>Año de fin de estudios: <?php echo $_REQUEST['año']?></p>
<p>Lista de codigos postales de las provincias: <?php 
function recogidaDeDatos($var, $valoresValidos){
    $resul="";
    foreach($var as $clave =>$valor){
        if( in_array($valor, $valoresValidos)){
           $resul.= $valor."; ";
        }
    }return $resul;
    
}
$valoresValidos=[20,21,22,23,24];
$valor=recogidaDeDatos($_REQUEST['ciudad'], $valoresValidos);
echo $valor; ?></p>
<p>Comentarios: <?php echo $_REQUEST['areadetexto']?></p>



</body>
</html>
<?php
