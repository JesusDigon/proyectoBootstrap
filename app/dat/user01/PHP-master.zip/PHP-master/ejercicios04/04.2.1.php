<!DOCTYPE unspecified PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head></head>
<body>
<h1>Calculadora</h1>
<form action="04.2.php">
<input type="number" name="num1">
<input type="number" name="num2"><br>
<input type="radio" name="operacion" value="+" checked>+<br>
<input type="radio" name="operacion" value="-">-<br>
<input type="radio" name="operacion" value="*">*<br>
<input type="radio" name="operacion" value="/">/<br>
<input type="radio" name="tipo" value="dec">Decimal
<input type="radio" name="tipo" value="bin">Binario
<input type="radio" name="tipo" value="hex">Hexadecimal<br>
<p><input type="submit" value="Calcular"></p> 
</form>
<h2>Resultado: 
<?php
$resultado= $_GET["Resultado"];
echo "$resultado"; ?></h2>


</body>
</html>
<?php show_source(__FILE__); ?>