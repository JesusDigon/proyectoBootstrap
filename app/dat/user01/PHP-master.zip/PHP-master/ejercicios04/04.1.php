<!DOCTYPE unspecified PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head></head>
<body>
<?php
$tabla= ["Pepe" => "1234", "Manolo" => "M1234", "Jose" => "1234" ];
foreach ($tabla as $clave => $valor){
    if($_REQUEST['Usuario']==$clave){
        if($_REQUEST['Contraseña']==$valor){
            echo "<h1>Bienvenido $clave</h1>";
            break;
        }
    } header("location:04.1.1.html");
}
?>
<?php show_source(__FILE__); ?>
</body>
</html>
