
<?php 
$resultado=0;
$condicion=true;

if($_REQUEST[num2]==0 && $_REQUEST[operacion]=="/"){

    $condicion=false;
    $resultado="No se puede dividir por 0";
}else{
    
    
    
}
    $op=$_REQUEST[operacion];
    $tipo=$_REQUEST[tipo];
    if($condicion){

    switch ($op){
        case "+" : $resultado= $_REQUEST[num1] + $_REQUEST[num2];
    break;
        case "-" : $resultado= $_REQUEST[num1] - $_REQUEST[num2];
    break;
        case "*" : $resultado= $_REQUEST[num1] * $_REQUEST[num2];
    break;
        case "/" : $resultado= $_REQUEST[num1] / $_REQUEST[num2];
    break;
    
    }
    switch ($tipo){
        case "dec": $resultado=$resultado;
        break;
        case "hex": $resultado= dechex($resultado);
        break;
        case "bin": $resultado= decbin($resultado);
        break;
    }

}


header("location:04.2.1.php?Resultado=$resultado");
?>
<?php show_source(__FILE__); ?>
