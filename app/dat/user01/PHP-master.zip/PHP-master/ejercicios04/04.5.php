<?php
$nombre=$_REQUEST['nombre'].$_REQUEST['apellidos'];
$mensaje="Bienvenid";
$aficiones=" ";
if(($_REQUEST['edad']== "Mayor de 55")&&($_REQUEST['sexo']=="mujer")){
    $nombre= "Doña ".$_REQUEST['nombre'];
    $mensaje.="a ".$nombre;
}elseif(($_REQUEST['edad']=="Mayor de 55")&&($_REQUEST['sexo']=="hombre")){
    $nombre="Don ".$_REQUEST['nombre'];
    $mensaje.="o ".$nombre;
}elseif($_REQUEST['sexo']=="hombre"){
    $mensaje.="o ".$nombre;
}else{
    $mensaje.="a ".$nombre;
}
if(!isset($_REQUEST['hobbie'])){
    $mensaje.= " no tiene aficiones";
}elseif(sizeof($_REQUEST['hobbie'])==1){
    $mensaje.= " su aficion es ".$_REQUEST['hobbie'][0];
}else{
    for($i=0;$i<sizeof($_REQUEST['hobbie']);$i++){
        if($i==sizeof($_REQUEST['hobbie'])-1){
            $aficiones.=$_REQUEST['hobbie'][$i].".";
        }elseif($i==sizeof($_REQUEST['hobbie'])-2){
                $aficiones.= $_REQUEST['hobbie'][$i]." y ";
        }else{
            $aficiones.= $_REQUEST['hobbie'][$i].",";
            }
    }
    $mensaje.=" sus aficiones son:".$aficiones;
}


echo $mensaje;


?>
<?php show_source(__FILE__); ?>